<html>
	<head>
		<link href="css.css" rel="stylesheet" type="text/css">
		<title  >Admin-IIITDMJ Vault</title>
	</head>
	<body>
		<div id="header">
			<div id="header1">
				<img id="logo" src="images/iiit.png">
				<h2 class="welcome">Welcome <span class="user">Admin</span></h2>
			</div>
			<a href=# class="header-faq">FAQs</a>
			<a href="signout.php" class="header-signout">SignOut</a>
		</div>
		
		<table id="main" >
			<tr>
			<td style="vertical-align:top">
			
			</td>
			<td style="padding-right: 100px;height: 500px;">
		    <div id="main-right" style="padding-bottom: 0px;align-content: center;padding-right: 100px;padding-top: 10px;">
		    <center>
		    
		<a href="view_transactions.php">view transactions</a></br>
		<a href="library.php">library</a></br>
		<a href="hostel.php">hostel</a></br>
		<a href="bus.php">bus</a></br>
		<a href="workshop.php">workshops</a></br>
		<a href="shirts.php">shirts</a></br>
		<a href="applications.php">applications</a></br>

</div>
			</td>
			</tr>
		</table>
			
			</div>
			</td>
			</tr>
		</table>
		</center>
		<div id="footer">
			
		</div>
		<script src="script.js"></script>
	</body>
</html>