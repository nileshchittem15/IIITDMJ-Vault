
<?php
	

	echo '<form action="changepass_check.php" method="post"><table align="center" border="0" cellspacing="10">
		  <tr><td>Current Password<super>*</super></td><td><input type="password" name="cpass"></td></tr>
		  <tr><td>New Password<super>*</super></td><td><input type="password" name="npass"></td></tr>
		  <tr><td>Retype New Password<super>*</super></td><td><input type="password" name="rnpass"></td></tr>
		  <tr><td colspan="2" align="center"><input type="submit" class="freshbutton-blue" value="Change Password"></td></tr></table></form>';

?>